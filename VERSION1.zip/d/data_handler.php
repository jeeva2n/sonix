<?php
session_start();
require_once 'functions.php';

// Ensure only admins can access
if (!isset($_SESSION['username']) || ($_SESSION['role'] ?? '') !== 'admin') {
    die('Access denied');
}

// Define available data files
$dataFiles = [
    'customers.csv' => 'Customer Database',
    'products.csv' => 'Product Catalog',
    'orders.csv' => 'Order Records',
    'order_history.csv' => 'Order History',
    'customer_history.csv' => 'Customer Activity Log',
    'product_history.csv' => 'Product Activity Log',
    'activity_log.csv' => 'System Activity Log',
    'document_uploads.csv' => 'Document Uploads Log',
    'folder_permissions.csv' => 'Folder Permissions'
];

// Get action and file parameters
$action = $_GET['action'] ?? '';
$filename = $_GET['file'] ?? '';
$customName = $_GET['name'] ?? '';

try {
    switch ($action) {
        case 'download':
            downloadCsvFile($filename, $customName);
            break;
            
        case 'view':
            viewCsvFile($filename, $customName);
            break;
            
        case 'download_all':
            downloadAllDataAsZip();
            break;
            
        case 'view_all':
            viewAllData();
            break;
            
        default:
            $_SESSION['message'] = ['type' => 'error', 'text' => 'Invalid action.'];
            header('Location: data_management.php');
            exit;
    }
} catch (Exception $e) {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Operation failed: ' . $e->getMessage()];
    header('Location: data_management.php');
    exit;
}

/**
 * Download a single CSV file
 */
function downloadCsvFile($filename, $customName = '') {
    global $dataFiles;
    
    // Validate filename
    if (!array_key_exists($filename, $dataFiles)) {
        throw new Exception('Invalid file specified.');
    }
    
    $filePath = DATA_PATH . $filename;
    
    if (!file_exists($filePath)) {
        throw new Exception('File not found: ' . $filename);
    }
    
    $displayName = $customName ?: $dataFiles[$filename];
    $safeFilename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $displayName) . '.csv';
    
    // Set headers for download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $safeFilename . '"');
    header('Content-Length: ' . filesize($filePath));
    header('Pragma: no-cache');
    header('Expires: 0');
    
    readfile($filePath);
    exit;
}

/**
 * View a single CSV file in browser
 */
function viewCsvFile($filename, $customName = '') {
    global $dataFiles;
    
    // Validate filename
    if (!array_key_exists($filename, $dataFiles)) {
        throw new Exception('Invalid file specified.');
    }
    
    $filePath = DATA_PATH . $filename;
    
    if (!file_exists($filePath)) {
        throw new Exception('File not found: ' . $filename);
    }
    
    $displayName = $customName ?: $dataFiles[$filename];
    $data = getCsvData($filename);
    displayCsvAsTable($data, $displayName, $filename);
    exit;
}

/**
 * Download all data as ZIP file
 */
function downloadAllDataAsZip() {
    global $dataFiles;
    
    $zipFilename = 'alphasonix_data_backup_' . date('Y-m-d_His') . '.zip';
    $zipPath = sys_get_temp_dir() . '/' . $zipFilename;
    
    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
        throw new Exception('Cannot create ZIP file');
    }
    
    foreach ($dataFiles as $filename => $displayName) {
        $filePath = DATA_PATH . $filename;
        
        if (file_exists($filePath) && filesize($filePath) > 0) {
            $safeName = preg_replace('/[^a-zA-Z0-9_-]/', '_', $displayName) . '.csv';
            $zip->addFile($filePath, $safeName);
        }
    }
    
    $zip->close();
    
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipFilename . '"');
    header('Content-Length: ' . filesize($zipPath));
    header('Pragma: no-cache');
    header('Expires: 0');
    
    readfile($zipPath);
    unlink($zipPath);
    exit;
}

/**
 * View all data in browser
 */
function viewAllData() {
    global $dataFiles;
    
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>All Data - Alphasonix CRM</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <style>
            body { padding: 20px; background: #f8f9fa; }
            .table-container { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; }
            h1 { color: #333; margin-bottom: 30px; }
            .back-btn { margin-bottom: 20px; }
            .table th { background-color: #f8f9fa; }
            .file-info { background: #e9ecef; padding: 10px 15px; border-radius: 5px; margin-bottom: 15px; }
        </style>
    </head>
    <body>
        <div class="container-fluid">
            <a href="data_management.php" class="btn btn-primary back-btn">
                <i class="fas fa-arrow-left"></i> Back to Data Management
            </a>
            <h1><i class="fas fa-database"></i> All System Data</h1>';
    
    foreach ($dataFiles as $filename => $displayName) {
        $filePath = DATA_PATH . $filename;
        
        if (file_exists($filePath) && filesize($filePath) > 0) {
            $data = getCsvData($filename);
            displayCsvAsTable($data, $displayName, $filename);
        } else {
            echo '<div class="table-container">
                    <div class="file-info">
                        <h4><i class="fas fa-file"></i> ' . htmlspecialchars($displayName) . '</h4>
                        <small class="text-muted">File: ' . htmlspecialchars($filename) . '</small>
                    </div>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> No data available or file is empty
                    </div>
                  </div>';
        }
    }
    
    echo '</div></body></html>';
    exit;
}

/**
 * Display CSV data as HTML table
 */
function displayCsvAsTable($data, $title, $filename) {
    if (empty($data)) {
        echo '<div class="table-container">
                <div class="file-info">
                    <h4><i class="fas fa-file"></i> ' . htmlspecialchars($title) . '</h4>
                    <small class="text-muted">File: ' . htmlspecialchars($filename) . '</small>
                </div>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> File exists but contains no records
                </div>
              </div>';
        return;
    }
    
    echo '<div class="table-container">
            <div class="file-info">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4><i class="fas fa-file-csv"></i> ' . htmlspecialchars($title) . '</h4>
                        <small class="text-muted">File: ' . htmlspecialchars($filename) . ' | ' . count($data) . ' records</small>
                    </div>
                    <a href="data_handler.php?action=download&file=' . urlencode($filename) . '&name=' . urlencode($title) . '" 
                       class="btn btn-success btn-sm">
                        <i class="fas fa-download"></i> Download CSV
                    </a>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>';
    
    // Table headers
    $headers = array_keys($data[0]);
    foreach ($headers as $header) {
        echo '<th>' . htmlspecialchars($header) . '</th>';
    }
    
    echo '</tr></thead><tbody>';
    
    // Table rows
    foreach ($data as $row) {
        echo '<tr>';
        foreach ($row as $cell) {
            // Truncate very long content for better display
            $displayCell = $cell;
            if (strlen($cell) > 100) {
                $displayCell = substr($cell, 0, 100) . '...';
            }
            echo '<td title="' . htmlspecialchars($cell) . '">' . htmlspecialchars($displayCell) . '</td>';
        }
        echo '</tr>';
    }
    
    echo '</tbody></table></div></div>';
}
?>