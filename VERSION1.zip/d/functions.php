<?php
define('DATA_PATH', __DIR__ . '/data/');
define('UPLOAD_BASE_PATH', __DIR__ . '/uploads/documents/');
define('ALLOWED_EXTENSIONS', ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'png', 'jpg', 'jpeg']);
define('MAX_FILE_SIZE', 10 * 1024 * 1024);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function getDataFilesList(): array
{
    $dataFiles = [];
    $files = [
        'activity_log.csv' => 'System Activity Log',
        'customers.csv' => 'Customers Data',
        'document_uploads.csv' => 'Document Uploads',
        'folder_permissions.csv' => 'Folder Permissions',
        'order_history.csv' => 'Order Change History',
        'orders.csv' => 'Orders Data',
        'products.csv' => 'Products Data'
    ];

    foreach ($files as $filename => $description) {
        $filePath = DATA_PATH . $filename;
        $dataFiles[] = [
            'filename' => $filename,
            'description' => $description,
            'size' => file_exists($filePath) ? filesize($filePath) : 0,
            'modified' => file_exists($filePath) ? filemtime($filePath) : 0,
            'records' => file_exists($filePath) ? count(getCsvData($filename)) : 0,
            'exists' => file_exists($filePath)
        ];
    }

    return $dataFiles;
}

function viewCsvFile(string $filename, string $customName = ''): void
{
    $filePath = DATA_PATH . $filename;

    if (!file_exists($filePath)) {
        throw new Exception("File not found: $filename");
    }

    $allowedFiles = [
        'activity_log.csv',
        'customers.csv',
        'document_uploads.csv',
        'folder_permissions.csv',
        'order_history.csv',
        'orders.csv',
        'products.csv'
    ];

    if (!in_array($filename, $allowedFiles)) {
        throw new Exception("Access denied for file: $filename");
    }

    $data = getCsvData($filename);
    $displayName = $customName ?: $filename;

    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>' . htmlspecialchars($displayName) . ' - Alphasonix CRM</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
        <style>
            body { background: #f8f9fa; padding: 20px; }
            .container { max-width: 1400px; }
            .header { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .table-container { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1><i class="bi bi-file-earmark-text"></i> ' . htmlspecialchars($displayName) . '</h1>
                        <p class="text-muted mb-0">' . count($data) . ' records found</p>
                    </div>
                    <a href="data_management.php" class="btn btn-primary">
                        <i class="bi bi-arrow-left"></i> Back to Data Management
                    </a>
                </div>
            </div>';

    if (!empty($data)) {
        echo '<div class="table-container">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-light">
                            <tr>';
        
        $headers = array_keys($data[0]);
        foreach ($headers as $header) {
            echo '<th>' . htmlspecialchars($header) . '</th>';
        }
        
        echo '</tr></thead><tbody>';
        
        foreach ($data as $row) {
            echo '<tr>';
            foreach ($row as $cell) {
                echo '<td>' . htmlspecialchars($cell) . '</td>';
            }
            echo '</tr>';
        }
        
        echo '</tbody></table></div></div>';
    } else {
        echo '<div class="alert alert-info text-center">
                <i class="bi bi-info-circle"></i> No data found in this file.
              </div>';
    }

    echo '</div></body></html>';
    exit;
}

function viewAllData(): void
{
    $files = [
        'activity_log.csv' => 'System Activity Log',
        'customers.csv' => 'Customers Data',
        'document_uploads.csv' => 'Document Uploads',
        'folder_permissions.csv' => 'Folder Permissions',
        'order_history.csv' => 'Order Change History',
        'orders.csv' => 'Orders Data',
        'products.csv' => 'Products Data'
    ];

    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>All Data - Alphasonix CRM</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
        <style>
            body { background: #f8f9fa; padding: 20px; }
            .container { max-width: 1400px; }
            .header { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
            .file-section { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1><i class="bi bi-database"></i> All System Data</h1>
                        <p class="text-muted mb-0">Complete data overview</p>
                    </div>
                    <a href="data_management.php" class="btn btn-primary">
                        <i class="bi bi-arrow-left"></i> Back to Data Management
                    </a>
                </div>
            </div>';

    foreach ($files as $filename => $description) {
        $filePath = DATA_PATH . $filename;
        $data = getCsvData($filename);
        
        echo '<div class="file-section">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4><i class="bi bi-file-earmark-text"></i> ' . htmlspecialchars($description) . '</h4>
                    <small class="text-muted">' . count($data) . ' records</small>
                </div>';
        
        if (!empty($data)) {
            echo '<div class="table-responsive">
                    <table class="table table-striped table-sm">
                        <thead class="table-light">
                            <tr>';
            
            $headers = array_keys($data[0]);
            foreach ($headers as $header) {
                echo '<th>' . htmlspecialchars($header) . '</th>';
            }
            
            echo '</tr></thead><tbody>';
            
            $displayData = array_slice($data, 0, 10);
            foreach ($displayData as $row) {
                echo '<tr>';
                foreach ($row as $cell) {
                    echo '<td>' . htmlspecialchars($cell) . '</td>';
                }
                echo '</tr>';
            }
            
            if (count($data) > 10) {
                echo '<tr><td colspan="' . count($headers) . '" class="text-center text-muted">
                        ... and ' . (count($data) - 10) . ' more records
                      </td></tr>';
            }
            
            echo '</tbody></table></div>';
        } else {
            echo '<div class="alert alert-info text-center">
                    <i class="bi bi-info-circle"></i> No data available
                  </div>';
        }
        
        echo '</div>';
    }

    echo '</div></body></html>';
    exit;
}

/**
 * Download a specific CSV file
 */
function downloadCsvFile($filename) {
    // Sanitize filename to prevent directory traversal
    $filename = basename($filename);
    $filePath = DATA_PATH . $filename;
    
    // Define allowed files for security
    $allowedFiles = [
        'activity_log.csv',
        'customers.csv',
        'document_uploads.csv',
        'folder_permissions.csv',
        'order_history.csv',
        'orders.csv',
        'products.csv'
    ];
    
    // Check if file is allowed
    if (!in_array($filename, $allowedFiles)) {
        throw new Exception("Access denied for file: $filename");
    }
    
    // Check if file exists
    if (!file_exists($filePath)) {
        throw new Exception("File not found: $filename");
    }
    
    // Get file size
    $fileSize = filesize($filePath);
    
    // Set headers for CSV download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . $fileSize);
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Expires: 0');
    
    // Clear output buffer
    ob_clean();
    flush();
    
    // Read and output the file
    readfile($filePath);
    exit;
}

function downloadAllDataAsZip(): void
{
    $zip = new ZipArchive();
    $zipFilename = 'system_data_backup_' . date('Y-m-d_H-i-s') . '.zip';
    $zipPath = sys_get_temp_dir() . '/' . $zipFilename;

    if ($zip->open($zipPath, ZipArchive::CREATE) !== TRUE) {
        throw new Exception('Cannot create ZIP file');
    }

    $files = [
        'activity_log.csv',
        'customers.csv',
        'document_uploads.csv',
        'folder_permissions.csv',
        'order_history.csv',
        'orders.csv',
        'products.csv'
    ];

    foreach ($files as $file) {
        $filePath = DATA_PATH . $file;
        if (file_exists($filePath)) {
            $zip->addFile($filePath, $file);
        }
    }

    $zip->close();

    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $zipFilename . '"');
    header('Content-Length: ' . filesize($zipPath));
    header('Pragma: no-cache');
    header('Expires: 0');

    readfile($zipPath);
    unlink($zipPath);
    exit;
}

function createBackup(): string
{
    $backupDir = DATA_PATH . 'backups/';
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0755, true);
    }

    $backupFilename = 'backup_' . date('Y-m-d_H-i-s') . '.zip';
    $backupPath = $backupDir . $backupFilename;

    $zip = new ZipArchive();
    if ($zip->open($backupPath, ZipArchive::CREATE) !== TRUE) {
        throw new Exception('Cannot create backup file');
    }

    $files = [
        'activity_log.csv',
        'customers.csv',
        'document_uploads.csv',
        'folder_permissions.csv',
        'order_history.csv',
        'orders.csv',
        'products.csv'
    ];

    foreach ($files as $file) {
        $filePath = DATA_PATH . $file;
        if (file_exists($filePath)) {
            $zip->addFile($filePath, $file);
        }
    }

    if (is_dir(UPLOAD_BASE_PATH)) {
        $uploadFiles = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(UPLOAD_BASE_PATH),
            RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ($uploadFiles as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen(__DIR__) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
    }

    $zip->close();
    return $backupPath;
}

function formatFileSize(int $bytes): string
{
    if ($bytes === 0) return '0 Bytes';

    $k = 1024;
    $sizes = ['Bytes', 'KB', 'MB', 'GB'];
    $i = floor(log($bytes) / log($k));

    return round($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}

function isAdmin(): bool
{
    return ($_SESSION['role'] ?? '') === 'admin';
}

function requireAuth(string $redirectUrl = ''): void
{
    if (!isset($_SESSION['username']) && !isset($_SESSION['login'])) {
        if (!empty($redirectUrl)) {
            $_SESSION['redirect_url'] = $redirectUrl;
        }
        header('Location: login.php');
        exit;
    }
}

function requireAdmin(string $redirectUrl = 'home.php'): void
{
    requireAuth($redirectUrl);

    if (!isAdmin()) {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Admin privileges required.'];
        header('Location: ' . $redirectUrl);
        exit;
    }
}

function generateUniqueId(string $filename, string $columnName, string $prefix = ''): string
{
    $filePath = DATA_PATH . $filename;
    $existingIds = [];

    if (file_exists($filePath) && ($handle = fopen($filePath, "r")) !== false) {
        $headers = fgetcsv($handle);
        $idIndex = $headers ? array_search($columnName, $headers) : false;

        if ($idIndex !== false) {
            while (($row = fgetcsv($handle)) !== false) {
                if (isset($row[$idIndex]) && $row[$idIndex] !== '') {
                    $existingIds[] = $row[$idIndex];
                }
            }
        }
        fclose($handle);
    }

    do {
        $letters = strtoupper(substr(preg_replace('/[^A-Z]/i', '', $prefix), 0, 3));
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

        while (strlen($letters) < 3) {
            $letters .= $alphabet[random_int(0, 25)];
        }

        $numbers = str_pad((string) random_int(0, 9999), 4, '0', STR_PAD_LEFT);
        $uniqueId = $letters . $numbers;
    } while (in_array($uniqueId, $existingIds, true));

    return $uniqueId;
}

function getNextCustomerId(): string
{
    $customers = getCsvData('customers.csv');
    $maxId = 100;

    foreach ($customers as $customer) {
        $id = $customer['id'] ?? '';
        if (is_numeric($id) && (int) $id > $maxId) {
            $maxId = (int) $id;
        }
    }

    return (string) ($maxId + 1);
}

function getCsvData(string $filename): array
{
    $filePath = DATA_PATH . $filename;
    if (!file_exists($filePath)) {
        return [];
    }

    $data = [];
    if (($handle = fopen($filePath, 'r')) !== FALSE) {
        $header = fgetcsv($handle);
        if ($header === FALSE) {
            fclose($handle);
            return [];
        }

        while (($row = fgetcsv($handle)) !== FALSE) {
            if (count($header) == count($row)) {
                $data[] = array_combine($header, $row);
            }
        }
        fclose($handle);
    }

    return $data;
}

function saveCsvData(string $filename, array $data): bool
{
    $filePath = DATA_PATH . $filename;

    if (!is_dir(DATA_PATH)) {
        mkdir(DATA_PATH, 0755, true);
    }

    $handle = fopen($filePath, 'w');
    if ($handle === false) {
        return false;
    }

    if (!empty($data)) {
        $headers = array_keys($data[0]);
        fputcsv($handle, $headers);
        
        foreach ($data as $row) {
            fputcsv($handle, array_values($row));
        }
    }

    fclose($handle);
    return true;
}

function appendCsvData(string $filename, array $data): bool
{
    $filePath = DATA_PATH . $filename;

    if (!is_dir(DATA_PATH)) {
        mkdir(DATA_PATH, 0755, true);
    }

    $fileExists = file_exists($filePath);
    $handle = fopen($filePath, 'a');
    
    if ($handle === false) {
        return false;
    }

    if (!$fileExists && !empty($data)) {
        $headers = array_keys($data);
        fputcsv($handle, $headers);
    }

    fputcsv($handle, $data);
    fclose($handle);
    return true;
}

function sanitize_input(string $data): string
{
    return htmlspecialchars(stripslashes(trim($data)), ENT_QUOTES, 'UTF-8');
}

function updateCsvRow(string $filename, string $id, string $id_column, array $new_data): bool
{
    $filePath = DATA_PATH . $filename;
    if (!file_exists($filePath)) {
        return false;
    }

    $data = [];
    $header = [];
    $updated = false;

    if (($handle = fopen($filePath, 'r')) !== FALSE) {
        $header = fgetcsv($handle);
        if ($header === FALSE) {
            fclose($handle);
            return false;
        }

        while (($row = fgetcsv($handle)) !== FALSE) {
            if (count($header) == count($row)) {
                $data[] = array_combine($header, $row);
            }
        }
        fclose($handle);
    } else {
        return false;
    }

    foreach ($data as &$row_ref) {
        if (isset($row_ref[$id_column]) && $row_ref[$id_column] === $id) {
            foreach ($new_data as $key => $value) {
                if (isset($row_ref[$key])) {
                    $row_ref[$key] = $value;
                }
            }
            $updated = true;
            break;
        }
    }

    if ($updated) {
        if (($handle = fopen($filePath, 'w')) !== FALSE) {
            fputcsv($handle, $header);
            foreach ($data as $row_data) {
                fputcsv($handle, array_values($row_data));
            }
            fclose($handle);
            return true;
        }
    }

    return false;
}

function deleteCsvRow(string $filename, string $value, string $field): bool
{
    $filePath = DATA_PATH . $filename;
    if (!file_exists($filePath)) {
        return false;
    }

    $data = [];
    $header = [];
    $deleted = false;

    if (($handle = fopen($filePath, 'r')) !== FALSE) {
        $header = fgetcsv($handle);
        if ($header === FALSE) {
            fclose($handle);
            return false;
        }

        while (($row = fgetcsv($handle)) !== FALSE) {
            if (count($header) == count($row)) {
                $rowData = array_combine($header, $row);
                if (($rowData[$field] ?? '') !== $value) {
                    $data[] = $rowData;
                } else {
                    $deleted = true;
                }
            }
        }
        fclose($handle);
    } else {
        return false;
    }

    if ($deleted) {
        if (($handle = fopen($filePath, 'w')) !== FALSE) {
            fputcsv($handle, $header);
            foreach ($data as $rowData) {
                fputcsv($handle, array_values($rowData));
            }
            fclose($handle);
            return true;
        }
    }

    return false;
}

function ensureCsvFile(string $filename, array $headers): bool
{
    $filePath = DATA_PATH . $filename;

    if (!is_dir(DATA_PATH)) {
        mkdir(DATA_PATH, 0755, true);
    }

    if (!file_exists($filePath)) {
        $handle = fopen($filePath, 'w');
        if ($handle !== FALSE) {
            fputcsv($handle, $headers);
            fclose($handle);
            return true;
        }
        return false;
    }

    return true;
}

function getCsvRowCount(string $filename): int
{
    return count(getCsvData($filename));
}

function searchCsvData(string $filename, string $field, string $searchTerm): array
{
    $allData = getCsvData($filename);
    $results = [];

    foreach ($allData as $row) {
        if (isset($row[$field]) && stripos($row[$field], $searchTerm) !== false) {
            $results[] = $row;
        }
    }

    return $results;
}

function csvValueExists(string $filename, string $field, string $value): bool
{
    $data = getCsvData($filename);

    foreach ($data as $row) {
        if (($row[$field] ?? '') === $value) {
            return true;
        }
    }

    return false;
}

function getCsvRowByField(string $filename, string $field, string $value): ?array
{
    $data = getCsvData($filename);

    foreach ($data as $row) {
        if (($row[$field] ?? '') === $value) {
            return $row;
        }
    }

    return null;
}

function getNextOrderId(): string
{
    $orders = getCsvData('orders.csv');
    $maxId = 1000;

    foreach ($orders as $order) {
        $orderId = $order['order_id'] ?? '';

        if (is_numeric($orderId) && (int) $orderId > $maxId) {
            $maxId = (int) $orderId;
        } else if (!is_numeric($orderId)) {
            preg_match('/\d+/', $orderId, $matches);
            if (!empty($matches[0])) {
                $numericPart = (int) $matches[0];
                if ($numericPart > $maxId) {
                    $maxId = $numericPart;
                }
            }
        }
    }

    return (string) ($maxId + 1);
}

function logActivity(string $action, string $details = ''): void
{
    $logEntry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'user' => $_SESSION['username'] ?? $_SESSION['login'] ?? 'System',
        'action' => $action,
        'details' => $details,
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown'
    ];

    ensureCsvFile('activity_log.csv', ['timestamp', 'user', 'action', 'details', 'ip_address']);
    appendCsvData('activity_log.csv', $logEntry);
}

function logPipelineChange(string $orderId, string $stage, string $description, string $itemIndex = null): void
{
    $currentUser = $_SESSION['username'] ?? 'System';
    $userId = $_SESSION['user_id'] ?? $currentUser;
    $userRole = $_SESSION['role'] ?? 'employee';
    
    $changeEntry = [
        'order_id' => $orderId,
        'change_date' => date('Y-m-d H:i:s'),
        'changed_by' => $currentUser,
        'user_id' => $userId,
        'user_role' => $userRole,
        'stage' => $stage,
        'change_description' => $description,
        'item_index' => $itemIndex ?? ''
    ];

    appendCsvData('order_history.csv', $changeEntry);
    
    $action = "Pipeline: " . $stage;
    logPipelineActivity($action, $orderId, $description, $itemIndex, $stage);
}

function isValidEmail(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function isValidPhone(string $phone): bool
{
    return preg_match('/^[\d\s\-\+\(\)]{10,}$/', $phone) === 1;
}

function getCurrentDateTime(): string
{
    return date('Y-m-d H:i:s');
}

function sanitizeFilePath(string $path): string
{
    $path = str_replace(['../', './'], '', $path);
    $path = str_replace("\0", '', $path);
    return preg_replace('/[^a-zA-Z0-9_\-\.\/]/', '', $path);
}

function hasAccessToFolder(string $folderPath, string $userRole, string $userId): bool
{
    if ($userRole === 'admin') {
        return true;
    }
    
    $folderName = basename($folderPath);
    
    if (strpos($folderName, $userId . '_') === 0) {
        return true;
    }
    
    if (!preg_match('/^\w+_/', $folderName)) {
        return true;
    }
    
    return false;
}

function hasModifyPermission(string $filePath, string $userRole, string $userId): bool
{
    if ($userRole === 'admin') {
        return true;
    }
    
    $folderPath = dirname($filePath);
    return hasAccessToFolder($folderPath, $userRole, $userId);
}

function getFoldersWithAccess(string $basePath, string $type, string $userRole, string $userId): array
{
    $folders = [];
    $path = $basePath . ($type ? $type . '/' : '');
    
    if (is_dir($path)) {
        $items = scandir($path);
        foreach ($items as $item) {
            if ($item != '.' && $item != '..' && is_dir($path . $item)) {
                $folderPath = ($type ? $type . '/' : '') . $item;
                if (hasAccessToFolder($folderPath, $userRole, $userId)) {
                    $folders[] = $folderPath;
                }
            }
        }
    }
    
    return $folders;
}

function getAllFolders(string $basePath): array
{
    $folders = [];
    $types = ['jobsheets', 'invoices'];
    
    foreach ($types as $type) {
        $path = $basePath . $type . '/';
        if (is_dir($path)) {
            $items = scandir($path);
            foreach ($items as $item) {
                if ($item != '.' && $item != '..' && is_dir($path . $item)) {
                    $folders[] = $type . '/' . $item;
                }
            }
        }
    }
    
    return $folders;
}

function getFilesInFolder(string $folderPath, string $userRole, string $userId): array
{
    if (!hasAccessToFolder($folderPath, $userRole, $userId)) {
        return [];
    }
    
    $files = [];
    $fullPath = UPLOAD_BASE_PATH . $folderPath;
    
    if (is_dir($fullPath)) {
        $items = scandir($fullPath);
        foreach ($items as $item) {
            if ($item != '.' && $item != '..' && is_file($fullPath . '/' . $item)) {
                $files[] = [
                    'name' => $item,
                    'size' => filesize($fullPath . '/' . $item),
                    'modified' => filemtime($fullPath . '/' . $item),
                    'path' => $folderPath . '/' . $item
                ];
            }
        }
    }
    
    return $files;
}

function getFileDisplayInfo(string $filePath, string $userRole, string $userId): array
{
    $fullPath = UPLOAD_BASE_PATH . $filePath;
    $fileInfo = [];
    
    if (file_exists($fullPath)) {
        $fileInfo = [
            'name' => basename($filePath),
            'size' => filesize($fullPath),
            'modified' => filemtime($fullPath),
            'can_view' => true,
            'can_download' => true,
            'can_replace' => ($userRole === 'admin'),
            'can_delete' => hasModifyPermission($filePath, $userRole, $userId)
        ];
    }
    
    return $fileInfo;
}

function getUserUploadHistory(string $userId, string $userRole, int $limit = 10): array
{
    ensureCsvFile('document_uploads.csv', ['upload_id', 'folder', 'filename', 'original_filename', 'document_type', 'description', 'uploaded_by', 'uploaded_by_id', 'upload_date', 'file_size']);
    
    $uploads = getCsvData('document_uploads.csv');
    $userUploads = [];
    
    foreach (array_reverse($uploads) as $upload) {
        if ($userRole === 'admin' || $upload['uploaded_by_id'] === $userId) {
            $userUploads[] = $upload;
            if (count($userUploads) >= $limit) {
                break;
            }
        }
    }
    
    return $userUploads;
}

function getAllUploadHistory(int $limit = 20): array
{
    ensureCsvFile('document_uploads.csv', ['upload_id', 'folder', 'filename', 'original_filename', 'document_type', 'description', 'uploaded_by', 'uploaded_by_id', 'upload_date', 'file_size']);
    
    $uploads = getCsvData('document_uploads.csv');
    return array_slice(array_reverse($uploads), 0, $limit);
}

function getAvailableUsers(): array
{
    $users = [];
    if (file_exists(DATA_PATH . 'users.csv')) {
        $userData = getCsvData('users.csv');
        foreach ($userData as $user) {
            if (isset($user['username']) && isset($user['user_id'])) {
                $users[$user['user_id']] = $user['username'];
            }
        }
    }
    return $users;
}

function getUserById(string $userId): ?array
{
    if (file_exists(DATA_PATH . 'users.csv')) {
        $users = getCsvData('users.csv');
        foreach ($users as $user) {
            if (($user['user_id'] ?? '') === $userId) {
                return $user;
            }
        }
    }
    return null;
}

function getUserByUsername(string $username): ?array
{
    if (file_exists(DATA_PATH . 'users.csv')) {
        $users = getCsvData('users.csv');
        foreach ($users as $user) {
            if (($user['username'] ?? '') === $username) {
                return $user;
            }
        }
    }
    return null;
}

function verifyUserCredentials(string $username, string $password): ?array
{
    $user = getUserByUsername($username);
    if ($user && password_verify($password, $user['password_hash'] ?? '')) {
        return $user;
    }
    return null;
}

function createUser(string $username, string $password, string $role = 'employee', array $additionalData = []): bool
{
    $usersFile = DATA_PATH . 'users.csv';
    
    if (getUserByUsername($username)) {
        return false;
    }

    $userData = [
        'user_id' => generateUniqueId('users.csv', 'user_id', 'USR'),
        'username' => $username,
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        'role' => $role,
        'created_at' => getCurrentDateTime(),
        'is_active' => '1'
    ];

    $userData = array_merge($userData, $additionalData);

    ensureCsvFile('users.csv', ['user_id', 'username', 'password_hash', 'role', 'created_at', 'is_active']);
    return appendCsvData('users.csv', $userData);
}

function generateCsrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(string $token): bool
{
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function redirectWithMessage(string $url, string $message, string $type = 'success'): void
{
    $_SESSION['message'] = ['type' => $type, 'text' => $message];
    header('Location: ' . $url);
    exit;
}

function getFlashMessage(): ?array
{
    $message = $_SESSION['message'] ?? null;
    unset($_SESSION['message']);
    return $message;
}

function getSystemStats(): array
{
    $stats = [
        'total_customers' => getCsvRowCount('customers.csv'),
        'total_orders' => getCsvRowCount('orders.csv'),
        'total_products' => getCsvRowCount('products.csv'),
        'total_uploads' => getCsvRowCount('document_uploads.csv'),
        'total_activities' => getCsvRowCount('activity_log.csv'),
        'system_uptime' => time() - (file_exists(DATA_PATH . 'activity_log.csv') ? filemtime(DATA_PATH . 'activity_log.csv') : time())
    ];

    return $stats;
}

function logPipelineActivity(string $action, string $orderId, string $details = '', string $itemIndex = null, string $stage = null): void
{
    $currentUser = $_SESSION['username'] ?? 'System';
    $userId = $_SESSION['user_id'] ?? $currentUser;
    $userRole = $_SESSION['role'] ?? 'employee';
    
    $logEntry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'user' => $currentUser,
        'user_id' => $userId,
        'user_role' => $userRole,
        'action' => $action,
        'details' => $details,
        'entity_type' => 'order',
        'entity_id' => $orderId,
        'item_index' => $itemIndex ?? '',
        'stage' => $stage ?? '',
        'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'Unknown'
    ];

    ensureCsvFile('activity_log.csv', [
        'timestamp', 'user', 'user_id', 'user_role', 'action', 'details', 
        'entity_type', 'entity_id', 'item_index', 'stage', 'ip_address'
    ]);
    
    appendCsvData('activity_log.csv', $logEntry);
}

function logOrderStatusChange(string $orderId, string $oldStatus, string $newStatus): void
{
    $details = "Status changed from '$oldStatus' to '$newStatus'";
    logPipelineActivity('ORDER_STATUS_UPDATE', $orderId, $details, null, 'Order Management');
}

function logItemStatusChange(string $orderId, string $itemName, string $oldStatus, string $newStatus, int $itemIndex): void
{
    $details = "Item '$itemName' status changed from '$oldStatus' to '$newStatus'";
    logPipelineActivity('ITEM_STATUS_UPDATE', $orderId, $details, $itemIndex, 'Item Management');
}

function logFileUpload(string $orderId, string $filename, string $fileType, int $itemIndex = null): void
{
    $details = "Uploaded $fileType: $filename";
    $stage = $fileType === 'drawing' ? 'Drawing Upload' : 'Document Upload';
    logPipelineActivity('FILE_UPLOAD', $orderId, $details, $itemIndex, $stage);
}

function logRawMaterialAdded(string $orderId, string $materialType, string $vendor, int $itemIndex): void
{
    $details = "Added raw material: $materialType from vendor: $vendor";
    logPipelineActivity('RAW_MATERIAL_ADDED', $orderId, $details, $itemIndex, 'Material Sourcing');
}
function logMachiningProcessUpdate(string $orderId, string $processName, string $status, int $itemIndex): void
{
    $details = "Process '$processName' updated to status: $status";
    logPipelineActivity('MACHINING_PROCESS_UPDATE', $orderId, $details, $itemIndex, 'Production');
}

function logQualityInspection(string $orderId, string $inspectionType, string $result, int $itemIndex): void
{
    $details = "$inspectionType inspection completed with result: $result";
    logPipelineActivity('QUALITY_INSPECTION', $orderId, $details, $itemIndex, 'Quality Control');
}

function logPackagingActivity(string $orderId, string $lotInfo, int $itemIndex): void
{
    $details = "Packaging lot created: $lotInfo";
    logPipelineActivity('PACKAGING_LOT_CREATED', $orderId, $details, $itemIndex, 'Packaging');
}

function logShippingActivity(string $orderId, string $trackingInfo, int $itemIndex): void
{
    $details = "Shipping documents uploaded: $trackingInfo";
    logPipelineActivity('SHIPPING_DOCUMENTS', $orderId, $details, $itemIndex, 'Shipping');
}

function logDispatchActivity(string $orderId, string $dispatchInfo, int $itemIndex): void
{
    $details = "Order dispatched: $dispatchInfo";
    logPipelineActivity('ORDER_DISPATCHED', $orderId, $details, $itemIndex, 'Dispatch');
}

function logDeletionActivity(string $orderId, string $entityType, string $entityName): void
{
    $details = "Deleted $entityType: $entityName";
    logPipelineActivity('ENTITY_DELETED', $orderId, $details, null, 'System');
}

function getActivityHistory($page = 1, $perPage = 50, $searchTerm = '') {
    $offset = ($page - 1) * $perPage;
    $allLogs = getCsvData('activity_log.csv');
    
    // Filter by search term
    if (!empty($searchTerm)) {
        $allLogs = array_filter($allLogs, function($log) use ($searchTerm) {
            return stripos($log['user'] ?? '', $searchTerm) !== false ||
                   stripos($log['action'] ?? '', $searchTerm) !== false ||
                   stripos($log['details'] ?? '', $searchTerm) !== false ||
                   stripos($log['ip_address'] ?? '', $searchTerm) !== false ||
                   stripos($log['stage'] ?? '', $searchTerm) !== false;
        });
    }
    
    // Sort by timestamp descending (newest first)
    usort($allLogs, function($a, $b) {
        return strtotime($b['timestamp'] ?? '') - strtotime($a['timestamp'] ?? '');
    });
    
    $totalLogs = count($allLogs);
    $logs = array_slice($allLogs, $offset, $perPage);
    
    $totalPages = ceil($totalLogs / $perPage);
    
    return [
        'logs' => $logs,
        'total_logs' => $totalLogs,
        'current_page' => $page,
        'total_pages' => $totalPages,
        'has_previous' => $page > 1,
        'has_next' => $page < $totalPages
    ];
}

function getActivityActionTypes(): array
{
    $logs = getCsvData('activity_log.csv');
    $actionTypes = [];
    
    foreach ($logs as $log) {
        $action = $log['action'] ?? '';
        if ($action && !in_array($action, $actionTypes)) {
            $actionTypes[] = $action;
        }
    }
    
    sort($actionTypes);
    return $actionTypes;
}

function getActivityUsers(): array
{
    $logs = getCsvData('activity_log.csv');
    $users = [];
    
    foreach ($logs as $log) {
        $user = $log['user'] ?? '';
        if ($user && $user !== 'System' && !in_array($user, $users)) {
            $users[] = $user;
        }
    }
    
    sort($users);
    return $users;
}

function getActivityStages(): array
{
    $logs = getCsvData('activity_log.csv');
    $stages = [];
    
    foreach ($logs as $log) {
        $stage = $log['stage'] ?? '';
        if ($stage && !in_array($stage, $stages)) {
            $stages[] = $stage;
        }
    }
    
    sort($stages);
    return $stages;
}

function getActivityStats(): array
{
    $logs = getCsvData('activity_log.csv');
    $stats = [
        'total_activities' => count($logs),
        'today_activities' => 0,
        'unique_users' => 0,
        'most_active_user' => '',
        'most_common_action' => ''
    ];
    
    $userCounts = [];
    $actionCounts = [];
    $today = date('Y-m-d');
    
    foreach ($logs as $log) {
        $logDate = date('Y-m-d', strtotime($log['timestamp'] ?? ''));
        if ($logDate === $today) {
            $stats['today_activities']++;
        }
        
        $user = $log['user'] ?? '';
        if ($user) {
            $userCounts[$user] = ($userCounts[$user] ?? 0) + 1;
        }
        
        $action = $log['action'] ?? '';
        if ($action) {
            $actionCounts[$action] = ($actionCounts[$action] ?? 0) + 1;
        }
    }
    
    if (!empty($userCounts)) {
        arsort($userCounts);
        $stats['most_active_user'] = array_key_first($userCounts);
        $stats['unique_users'] = count($userCounts);
    }
    
    if (!empty($actionCounts)) {
        arsort($actionCounts);
        $stats['most_common_action'] = array_key_first($actionCounts);
    }
    
    return $stats;
}

?>
