<?php
session_start();
require_once 'functions.php';

/**
 * Handles the secure upload of a file associated with an order item.
 *
 * @param array $fileArray The specific file entry from the $_FILES superglobal (e.g., $_FILES['drawing_file']).
 * @param int $index The index of the file in the array.
 * @param string $orderId The ID of the order.
 * @param string $itemId The ID of the item.
 * @return array An array containing 'filename', 'original', and 'error' keys.
 */
function handleItemFileUpload($fileArray, $index, $orderId, $itemId)
{
    $uploadResult = ['filename' => '', 'original' => '', 'error' => null];

    if (isset($fileArray['name'][$index]) && $fileArray['error'][$index] === UPLOAD_ERR_OK) {
        // --- Security Checks ---
        $file_tmp_name = $fileArray['tmp_name'][$index];
        $file_name = basename($fileArray['name'][$index]);
        $file_size = $fileArray['size'][$index];
        $max_file_size = 10 * 1024 * 1024; // 10 MB

        // --- MODIFICATION: The file extension check has been removed as per your request. ---
        // --- SECURITY WARNING: This is NOT recommended as it allows any file type to be uploaded. ---
        /*
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_extensions = ['jpg', 'jpeg', 'png', 'pdf', 'dwg'];
        if (!in_array($file_ext, $allowed_extensions)) {
            $uploadResult['error'] = 'Invalid file type. Allowed types: ' . implode(', ', $allowed_extensions);
            return $uploadResult;
        }
        */

        if ($file_size > $max_file_size) {
            $uploadResult['error'] = 'File size exceeds the limit of 10 MB.';
            return $uploadResult;
        }

        // --- Directory and Filename Handling ---
        $uploadDir = __DIR__ . '/uploads/drawings/';
        if (!is_dir($uploadDir)) {
            // Create directory with more secure permissions
            if (!mkdir($uploadDir, 0755, true)) {
                 $uploadResult['error'] = 'Failed to create upload directory.';
                 return $uploadResult;
            }
        }
        
        // Sanitize filename to prevent directory traversal and other issues
        $safe_original_name = preg_replace("/[^a-zA-Z0-9\._-]/", "", $file_name);
        $newFilename = $orderId . '_' . $itemId . '_' . time() . '_' . $safe_original_name;

        if (move_uploaded_file($file_tmp_name, $uploadDir . $newFilename)) {
            $uploadResult['filename'] = $newFilename;
            $uploadResult['original'] = $file_name;
        } else {
            $uploadResult['error'] = 'Failed to move uploaded file.';
        }
    } elseif (isset($fileArray['error'][$index]) && $fileArray['error'][$index] !== UPLOAD_ERR_NO_FILE) {
        // Handle other potential upload errors
        $uploadResult['error'] = 'File upload error code: ' . $fileArray['error'][$index];
    }
    
    return $uploadResult;
}

/**
 * Creates a structured array representing an order item.
 *
 * @param string $sNo The item's Serial Number or ID.
 * @param string $name The name of the item.
 * @param string $dimensions The dimensions of the item.
 * @param string $description The description for the item.
 * @param int $quantity The quantity of the item.
 * @param array $drawingData Data from handleItemFileUpload.
 * @return array The structured order item.
 */
function createOrderItem($sNo, $name, $dimensions, $description, $quantity, $drawingData)
{
    return [
        'S.No' => $sNo,
        'Name' => $name,
        'Dimensions' => $dimensions,
        'Description' => $description,
        'quantity' => $quantity,
        'item_status' => 'Pending',
        'drawing_filename' => $drawingData['filename'],
        'original_filename' => $drawingData['original'],
        'raw_materials' => [],
        'machining_processes' => []
    ];
}

// --- STAGE 1: Handle Order Creation ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_order'])) {
    $customerId = sanitize_input($_POST['customer_id']);
    $poDate = sanitize_input($_POST['po_date']);
    $deliveryDate = sanitize_input($_POST['delivery_date']);

    $orderId = getNextOrderId();
    $products = getCsvData('products.csv');
    $productDetailsMap = array_column($products, null, 'S.No');
    $orderItems = [];
    $uploadErrors = [];

    // Process existing products
    if (isset($_POST['product_sno']) && is_array($_POST['product_sno'])) {
        foreach ($_POST['product_sno'] as $index => $productSNo) {
            if (!empty($productSNo) && isset($productDetailsMap[$productSNo])) {
                $quantity = (int) ($_POST['quantity'][$index] ?? 1);
                if ($quantity > 0) {
                    $product = $productDetailsMap[$productSNo];
                    $dimensions = sanitize_input($_POST['product_dimensions'][$index] ?? '');
                    $description = sanitize_input($_POST['product_description'][$index] ?? '');
                    $drawingData = handleItemFileUpload($_FILES['drawing_file_existing'], $index, $orderId, $productSNo);

                    if ($drawingData['error']) {
                        $uploadErrors[] = "Error for product '{$product['Name']}': {$drawingData['error']}";
                        continue; // Skip this item if file upload failed
                    }

                    $orderItems[] = createOrderItem(
                        $productSNo,
                        $product['Name'],
                        !empty($dimensions) ? $dimensions : $product['Dimensions'],
                        $description,
                        $quantity,
                        $drawingData
                    );
                }
            }
        }
    }

    // Process manual products
    if (isset($_POST['manual_product_name']) && is_array($_POST['manual_product_name'])) {
        foreach ($_POST['manual_product_name'] as $index => $manualName) {
            $manualName = sanitize_input($manualName);
            if (!empty($manualName)) {
                $manualQty = (int) ($_POST['manual_quantity'][$index] ?? 1);
                if ($manualQty > 0) {
                    $manualSNo = generateUniqueId('orders.csv', 'S.No', 'MAN');
                    $manualDimensions = sanitize_input($_POST['manual_product_dimensions'][$index] ?? '');
                    $manualDescription = sanitize_input($_POST['manual_product_description'][$index] ?? '');
                    $drawingData = handleItemFileUpload($_FILES['drawing_file_manual'], $index, $orderId, $manualSNo);

                    if ($drawingData['error']) {
                        $uploadErrors[] = "Error for custom product '{$manualName}': {$drawingData['error']}";
                        continue; // Skip this item
                    }
                    
                    $orderItems[] = createOrderItem(
                        $manualSNo,
                        $manualName,
                        $manualDimensions,
                        $manualDescription,
                        $manualQty,
                        $drawingData
                    );
                }
            }
        }
    }
    
    // Check for upload errors before proceeding
    if (!empty($uploadErrors)) {
        $_SESSION['message'] = ['type' => 'error', 'text' => implode('<br>', $uploadErrors)];
    } elseif (!empty($customerId) && !empty($orderItems) && !empty($poDate)) {
        $newOrder = [
            'order_id' => $orderId,
            'customer_id' => $customerId,
            'po_date' => $poDate,
            'delivery_date' => $deliveryDate,
            'due_date' => '',
            'items_json' => json_encode($orderItems),
            'status' => 'Pending',
            'drawing_filename' => '',
            'inspection_reports_json' => json_encode([])
        ];
        appendCsvData('orders.csv', $newOrder);

        $changeEntry = [
            'order_id' => $orderId,
            'change_date' => date('Y-m-d H:i:s'),
            'changed_by' => $_SESSION['username'] ?? 'System',
            'stage' => 'Order Creation',
            'change_description' => "New order created with " . count($orderItems) . " items",
            'item_index' => ''
        ];
        appendCsvData('order_history.csv', $changeEntry);

        $_SESSION['order_created'] = true;
        header('Location: pipeline.php');
        exit;
    } else {
        $_SESSION['message'] = ['type' => 'error', 'text' => 'Please select a client and add at least one valid product.'];
    }
}

// --- Get data for display ---
$customers = getCsvData('customers.csv');
$products = getCsvData('products.csv');
$orders = getCsvData('orders.csv');
$today = date('Y-m-d');

// Calculate stats for dashboard
$totalOrders = count($orders);
$totalCustomers = count($customers);
$totalProducts = count($products);

// Get recent orders for sidebar
$recentOrders = array_slice(array_reverse($orders), 0, 5);
$customerMap = array_column($customers, 'name', 'id');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Management - Alphasonix CRM</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Custom CSS -->
    <style>
        :root {
            --primary: #4361ee;
            --primary-light: #4895ef;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --info: #4895ef;
            --warning: #f72585;
            --danger: #e63946;
            --light: #f8f9fa;
            --dark: #212529;
            --gray: #6c757d;
            --light-gray: #e9ecef;
            --border-color: #dee2e6;
            --card-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            --card-shadow-hover: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background-color: #f5f7fb;
            color: #495057;
        }
        
        .dashboard-header {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border-radius: 0.75rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--card-shadow);
            border-left: 4px solid var(--primary);
        }
        
        .content-card {
            background: white;
            border-radius: 0.75rem;
            box-shadow: var(--card-shadow);
            border: none;
            margin-bottom: 1.5rem;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .content-card:hover {
            box-shadow: var(--card-shadow-hover);
        }
        
        .card-header-custom {
            background: white;
            border-bottom: 1px solid var(--border-color);
            padding: 1.25rem 1.5rem;
        }
        
        .card-body-custom {
            padding: 1.5rem;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(67, 97, 238, 0.25);
        }
        
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .btn-primary:hover {
            background-color: var(--secondary);
            border-color: var(--secondary);
        }
        
        .btn-success {
            background-color: var(--success);
            border-color: var(--success);
        }
        
        .btn-danger {
            background-color: var(--danger);
            border-color: var(--danger);
        }
        
        .btn-outline-primary {
            color: var(--primary);
            border-color: var(--primary);
        }
        
        .btn-outline-primary:hover {
            background-color: var(--primary);
            color: white;
        }
        
        /* Stats cards */
        .stat-card {
            background: white;
            border-radius: 0.75rem;
            padding: 1.25rem;
            box-shadow: var(--card-shadow);
            border: none;
            transition: all 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--card-shadow-hover);
        }
        
        /* Alert styles */
        .alert-success {
            background-color: rgba(76, 201, 240, 0.1);
            border-color: rgba(76, 201, 240, 0.3);
            color: #0c5460;
        }
        
        .alert-danger {
            background-color: rgba(230, 57, 70, 0.1);
            border-color: rgba(230, 57, 70, 0.3);
            color: #721c24;
        }
        
        /* Product entry styles */
        .product-entry {
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            padding: 1rem;
            margin-bottom: 1rem;
            background: var(--light);
        }
        
        .product-entry-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        
        .product-type-badge {
            background: var(--primary);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .product-form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .product-form-grid .full-width {
            grid-column: 1 / -1;
        }
        
        /* File upload styles */
        .file-upload-wrapper {
            position: relative;
        }
        
        .file-upload-label {
            display: block;
            border: 2px dashed var(--border-color);
            border-radius: 0.5rem;
            padding: 1.5rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .file-upload-label:hover {
            border-color: var(--primary);
            background: rgba(67, 97, 238, 0.05);
        }
        
        .file-upload-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
        }
        
        .file-preview-container {
            margin-top: 0.5rem;
            padding: 0.75rem;
            background: var(--light);
            border-radius: 0.375rem;
            border: 1px solid var(--border-color);
        }
        
        .selected-file-info {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        /* Timeline display */
        .timeline-display {
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            font-weight: 500;
            text-align: center;
        }
        
        .timeline-normal {
            background: rgba(76, 201, 240, 0.1);
            color: #0c5460;
            border: 1px solid rgba(76, 201, 240, 0.3);
        }
        
        .timeline-warning {
            background: rgba(247, 37, 133, 0.1);
            color: #721c24;
            border: 1px solid rgba(247, 37, 133, 0.3);
        }
        
        .timeline-urgent {
            background: rgba(230, 57, 70, 0.1);
            color: #721c24;
            border: 1px solid rgba(230, 57, 70, 0.3);
        }
        
        .timeline-overdue {
            background: rgba(230, 57, 70, 0.2);
            color: #721c24;
            border: 1px solid rgba(230, 57, 70, 0.5);
        }
        
        /* Recent orders */
        .recent-order-item {
            display: flex;
            align-items: center;
            padding: 0.75rem;
            border-bottom: 1px solid var(--border-color);
        }
        
        .recent-order-item:last-child {
            border-bottom: none;
        }
        
        .order-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            margin-right: 0.75rem;
        }
        
        .order-info {
            flex: 1;
        }
        
        .order-info strong {
            display: block;
            font-size: 0.875rem;
        }
        
        .order-info span {
            font-size: 0.75rem;
            color: var(--gray);
        }
        
        .status-badge {
            padding: 0.25rem 0.5rem;
            border-radius: 1rem;
            font-size: 0.75rem;
            font-weight: 500;
        }
        
        .status-pending {
            background: rgba(108, 117, 125, 0.1);
            color: var(--gray);
        }
        
        /* Quick actions */
        .quick-actions-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.5rem;
        }
        
        .quick-action-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 1rem;
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            text-decoration: none;
            color: var(--dark);
            transition: all 0.3s ease;
        }
        
        .quick-action-card:hover {
            background: var(--primary);
            color: white;
            text-decoration: none;
            transform: translateY(-2px);
        }
        
        .action-icon {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 2rem 1rem;
            color: var(--gray);
        }
        
        .empty-state .bi {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: var(--light-gray);
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>

    <!-- Main Content Area -->
    <div class="main-content">
        <div class="container-fluid py-4">
            <!-- Display messages -->
            <?php if (isset($_SESSION['message'])): ?>
                <?php 
                $messageType = $_SESSION['message']['type'];
                $alertClass = $messageType === 'success' ? 'alert-success' : 'alert-danger';
                echo "<div class='alert $alertClass alert-dismissible fade show' role='alert'>" .
                    $_SESSION['message']['text'] .
                    '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' .
                    "</div>";
                unset($_SESSION['message']);
                ?>
            <?php endif; ?>

            <!-- Header Section -->
            <div class="dashboard-header">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <h1 class="h3 mb-2">
                            <i class="bi bi-cart-plus me-2"></i>Order Management
                        </h1>
                        <p class="text-muted mb-0">Create and manage customer orders with real-time tracking</p>
                    </div>
                    <div class="text-end">
                        <div class="badge bg-light text-dark p-2">
                            <i class="bi bi-calendar3 me-1"></i> <?= date('l, F j, Y') ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <div class="bg-primary bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-file-text fs-4 text-primary"></i>
                                </div>
                            </div>
                            <div>
                                <h5 class="mb-1">Total Orders</h5>
                                <h2 class="mb-0 text-primary"><?= $totalOrders ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <div class="bg-success bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-people fs-4 text-success"></i>
                                </div>
                            </div>
                            <div>
                                <h5 class="mb-1">Active Clients</h5>
                                <h2 class="mb-0 text-success"><?= $totalCustomers ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="d-flex align-items-center">
                            <div class="me-3">
                                <div class="bg-info bg-opacity-10 p-3 rounded">
                                    <i class="bi bi-box-seam fs-4 text-info"></i>
                                </div>
                            </div>
                            <div>
                                <h5 class="mb-1">Products</h5>
                                <h2 class="mb-0 text-info"><?= $totalProducts ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Main Content Grid -->
            <div class="row">
                <!-- Order Creation Form -->
                <div class="col-lg-8 mb-4">
                    <div class="content-card">
                        <div class="card-header-custom">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="bi bi-plus-circle me-2"></i>Create New Order
                                </h5>
                                <span class="badge bg-primary">Step 1: Order Details</span>
                            </div>
                        </div>
                        <div class="card-body-custom">
                            <form action="orders.php" method="post" enctype="multipart/form-data">
                                <!-- Client and Date Information -->
                                <div class="mb-4">
                                    <h6 class="mb-3">
                                        <i class="bi bi-info-circle me-2"></i>Order Information
                                    </h6>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label for="customer_id" class="form-label">Client Name</label>
                                            <select name="customer_id" id="customer_id" class="form-select" required>
                                                <option value="">-- Choose a Client --</option>
                                                <?php foreach ($customers as $customer): ?>
                                                    <option value="<?= htmlspecialchars($customer['id']) ?>">
                                                        <?= htmlspecialchars($customer['name']) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="po_date" class="form-label">PO Date</label>
                                            <input type="date" id="po_date" name="po_date" class="form-control" value="<?= $today ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label for="delivery_date" class="form-label">Delivery Date</label>
                                            <input type="date" id="delivery_date" name="delivery_date" class="form-control"
                                                onchange="calculateDaysLeft()">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Timeline</label>
                                            <div id="days_remaining" class="timeline-display timeline-normal">
                                                <span class="timeline-label">Not set</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Products Section -->
                                <div class="mb-4">
                                    <h6 class="mb-3">
                                        <i class="bi bi-box-seam me-2"></i>Products & Items
                                    </h6>
                                    
                                    <!-- Existing Products -->
                                    <div class="mb-4">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h6 class="mb-0">
                                                <i class="bi bi-box me-2"></i>Catalog Products
                                            </h6>
                                            <button type="button" id="addExistingProductBtn" class="btn btn-outline-primary btn-sm">
                                                <i class="bi bi-plus me-1"></i>Add Product
                                            </button>
                                        </div>
                                        <div id="existingProductsContainer">
                                            <?= renderProductEntry('existing', $products); ?>
                                        </div>
                                    </div>

                                    <!-- Manual Products -->
                                    <div class="mb-4">
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h6 class="mb-0">
                                                <i class="bi bi-pencil me-2"></i>Custom Products
                                            </h6>
                                            <button type="button" id="addManualProductBtn" class="btn btn-outline-primary btn-sm">
                                                <i class="bi bi-plus me-1"></i>Add Custom
                                            </button>
                                        </div>
                                        <div id="manualProductsContainer">
                                            <?= renderProductEntry('manual'); ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Submit Section -->
                                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                    <button type="submit" name="create_order" class="btn btn-primary">
                                        <i class="bi bi-rocket-takeoff me-2"></i>
                                        Create Order & Start Pipeline
                                    </button>
                                    <button type="reset" class="btn btn-secondary">
                                        <i class="bi bi-arrow-clockwise me-2"></i>
                                        Reset Form
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Recent Orders & Quick Stats -->
                <div class="col-lg-4">
                    <!-- Recent Orders -->
                    <div class="content-card mb-4">
                        <div class="card-header-custom">
                            <div class="d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="bi bi-clock-history me-2"></i>Recent Orders
                                </h5>
                                <span class="badge bg-primary">Last 5</span>
                            </div>
                        </div>
                        <div class="card-body-custom p-0">
                            <div class="recent-orders-list">
                                <?php if (empty($recentOrders)): ?>
                                    <div class="empty-state">
                                        <i class="bi bi-inbox"></i>
                                        <h6>No Orders Yet</h6>
                                        <p class="mb-0 small">Create your first order to get started</p>
                                    </div>
                                <?php else: ?>
                                    <?php foreach ($recentOrders as $order): ?>
                                        <div class="recent-order-item">
                                            <div class="order-avatar">
                                                <?= strtoupper(substr($customerMap[$order['customer_id']] ?? 'C', 0, 1)) ?>
                                            </div>
                                            <div class="order-info">
                                                <strong>#<?= htmlspecialchars($order['order_id']) ?></strong>
                                                <span><?= htmlspecialchars($customerMap[$order['customer_id']] ?? 'Unknown') ?></span>
                                            </div>
                                            <div class="order-status">
                                                <?php
                                                $status = $order['status'] ?? 'Pending';
                                                $statusClass = 'status-badge status-' . strtolower(str_replace(' ', '-', $status));
                                                ?>
                                                <span class="<?= $statusClass ?>"><?= htmlspecialchars($status) ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="content-card">
                        <div class="card-header-custom">
                            <h5 class="mb-0">
                                <i class="bi bi-lightning me-2"></i>Quick Actions
                            </h5>
                        </div>
                        <div class="card-body-custom">
                            <div class="quick-actions-grid">
                                <a href="pipeline.php" class="quick-action-card">
                                    <div class="action-icon"><i class="bi bi-diagram-3"></i></div>
                                    <span>View Pipeline</span>
                                </a>
                                <a href="customers.php" class="quick-action-card">
                                    <div class="action-icon"><i class="bi bi-people"></i></div>
                                    <span>Manage Clients</span>
                                </a>
                                <a href="products.php" class="quick-action-card">
                                    <div class="action-icon"><i class="bi bi-box"></i></div>
                                    <span>Products</span>
                                </a>
                                <a href="home.php" class="quick-action-card">
                                    <div class="action-icon"><i class="bi bi-speedometer"></i></div>
                                    <span>Dashboard</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Helper functions
    const helpers = {
        clearProductEntry: function (entry, type) {
            const selectors = type === 'existing'
                ? ['select', 'input[name^="quantity"]', 'input[name^="product_dimensions"]', 'textarea[name^="product_description"]']
                : ['input[name^="manual_product_name"]', 'input[name^="manual_quantity"]', 'input[name^="manual_product_dimensions"]', 'textarea[name^="manual_product_description"]'];

            selectors.forEach(selector => {
                const elem = entry.querySelector(selector);
                if (elem) {
                    if (elem.tagName === 'SELECT') {
                        elem.selectedIndex = 0;
                    } else if (elem.type === 'number') {
                        elem.value = 1;
                    } else {
                        elem.value = '';
                    }
                }
            });

            const fileInput = entry.querySelector('input[type="file"]');
            if (fileInput) fileInput.value = null;

            const previewContainer = entry.querySelector('.file-preview-container');
            if (previewContainer) {
                previewContainer.style.display = 'none';
                previewContainer.querySelector('.file-name').textContent = '';
                previewContainer.querySelector('.file-size').textContent = '';
            }
        },

        addProductHandler: function (containerId, entryClass, type) {
            const container = document.getElementById(containerId);
            const firstEntry = container.querySelector('.product-entry');
            if (!firstEntry) return;
            const newEntry = firstEntry.cloneNode(true);

            // Generate new unique ID for file input and its label
            const newId = `file_${type}_${Date.now()}`;
            newEntry.querySelector('input[type="file"]').id = newId;
            newEntry.querySelector('label.file-upload-label').setAttribute('for', newId);

            helpers.clearProductEntry(newEntry, type);
            container.appendChild(newEntry);
        }
    };

    // Calculate days remaining between PO date and delivery date
    function calculateDaysLeft() {
        const poDateEl = document.getElementById('po_date');
        const deliveryDateEl = document.getElementById('delivery_date');
        const daysRemainingElement = document.getElementById('days_remaining');

        if (!poDateEl.value || !deliveryDateEl.value) {
            daysRemainingElement.innerHTML = '<span class="timeline-label">Not set</span>';
            daysRemainingElement.className = "timeline-display timeline-normal";
            return;
        }

        const poDate = new Date(poDateEl.value);
        const deliveryDate = new Date(deliveryDateEl.value);
        
        const diffTime = deliveryDate.getTime() - poDate.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        let timelineClass = 'timeline-normal';
        let icon = '📅';

        if (diffDays < 0) {
            timelineClass = 'timeline-overdue';
            icon = '⏰';
            daysRemainingElement.innerHTML = `<span class="timeline-icon">${icon}</span><span class="timeline-label">Overdue</span>`;
        } else if (diffDays < 7) {
            timelineClass = 'timeline-urgent';
            icon = '⚡';
            daysRemainingElement.innerHTML = `<span class="timeline-icon">${icon}</span><span class="timeline-label">${diffDays} day${diffDays !== 1 ? 's' : ''}</span>`;
        } else if (diffDays < 14) {
            timelineClass = 'timeline-warning';
            icon = '📋';
            daysRemainingElement.innerHTML = `<span class="timeline-icon">${icon}</span><span class="timeline-label">${diffDays} days</span>`;
        } else {
            timelineClass = 'timeline-normal';
            icon = '✅';
            daysRemainingElement.innerHTML = `<span class="timeline-icon">${icon}</span><span class="timeline-label">${diffDays} days</span>`;
        }

        daysRemainingElement.className = `timeline-display ${timelineClass}`;
    }

    // Auto-populate dimensions when product is selected
    function updateDimensions(selectElement) {
        const selectedOption = selectElement.options[selectElement.selectedIndex];
        const dimensionsInput = selectElement.closest('.product-entry').querySelector('.product-dimensions');

        if (selectedOption && selectedOption.value) {
            dimensionsInput.value = selectedOption.getAttribute('data-dimensions') || '';
        } else {
            dimensionsInput.value = '';
        }
    }

    // Preview selected file function
    function previewSelectedFile(inputElement) {
        const file = inputElement.files[0];
        const formGroup = inputElement.closest('.form-group');
        const previewContainer = formGroup.querySelector('.file-preview-container');

        if (file) {
            const fileNameEl = previewContainer.querySelector('.file-name');
            const fileSizeEl = previewContainer.querySelector('.file-size');
            const fileIconEl = previewContainer.querySelector('.file-icon');

            fileNameEl.textContent = file.name;
            fileSizeEl.textContent = `(${(file.size / 1024).toFixed(1)} KB)`;

            const iconMap = { 'image': '🖼️', 'pdf': '📄', 'dwg': '📐' };
            let icon = '📎'; // Default icon

            if (file.type.startsWith('image/')) icon = iconMap.image;
            else if (file.type === 'application/pdf') icon = iconMap.pdf;
            else if (file.name.toLowerCase().endsWith('.dwg')) icon = iconMap.dwg;
            
            fileIconEl.textContent = icon;
            previewContainer.style.display = 'flex';
        } else {
            previewContainer.style.display = 'none';
        }
    }

    // Product management event handlers
    document.getElementById('addExistingProductBtn').addEventListener('click', function () {
        helpers.addProductHandler('existingProductsContainer', 'existing-product-entry', 'existing');
    });

    document.getElementById('addManualProductBtn').addEventListener('click', function () {
        helpers.addProductHandler('manualProductsContainer', 'manual-product-entry', 'manual');
    });

    function removeProduct(button) {
        const entry = button.closest('.product-entry');
        const container = entry.parentElement;

        if (container.querySelectorAll('.product-entry').length > 1) {
            entry.remove();
        } else {
            const type = entry.classList.contains('existing-product-entry') ? 'existing' : 'manual';
            helpers.clearProductEntry(entry, type);
        }
    }

    // Initialize listeners and calculators on page load
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('delivery_date').addEventListener('change', calculateDaysLeft);
        document.getElementById('po_date').addEventListener('change', calculateDaysLeft);
        calculateDaysLeft();

        document.querySelectorAll('.product-select').forEach(select => {
            updateDimensions(select);
        });

        // Auto-hide alerts
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }, 5000);
        });
    });
    </script>
</body>
</html>
<?php
/**
 * Renders the HTML for a single product entry form, either for an existing or manual product.
 *
 * @param string $type The type of entry ('existing' or 'manual').
 * @param array|null $products An array of available products (required for 'existing' type).
 * @return string The generated HTML string.
 */
function renderProductEntry($type, $products = null)
{
    $isExisting = ($type === 'existing');
    $prefix = $isExisting ? '' : 'manual_';
    $class = $isExisting ? 'existing-product-entry' : 'manual-product-entry';
    $uniqueFileId = 'file_' . $type . '_' . uniqid();

    ob_start();
    ?>
    <div class="product-entry <?= $class ?>">
        <div class="product-entry-header">
            <div class="product-type-badge">
                <i class="bi <?= $isExisting ? 'bi-box' : 'bi-pencil' ?>"></i>
                <?= $isExisting ? 'Catalog Item' : 'Custom Item' ?>
            </div>
            <button type="button" class="btn btn-danger btn-sm remove-product-btn" onclick="removeProduct(this)">
                <i class="bi bi-x"></i>
            </button>
        </div>
        <div class="product-form-grid">
            <?php if ($isExisting): ?>
                <div class="form-group">
                    <label class="form-label">Product Selection</label>
                    <select name="product_sno[]" class="form-select product-select" onchange="updateDimensions(this)">
                        <option value="">-- Select Product --</option>
                        <?php foreach ($products as $product): ?>
                            <option value="<?= htmlspecialchars($product['S.No']) ?>"
                                data-dimensions="<?= htmlspecialchars($product['Dimensions']) ?>">
                                <?= htmlspecialchars($product['Name']) ?> (<?= htmlspecialchars($product['S.No']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php else: ?>
                <div class="form-group">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="manual_product_name[]" placeholder="Enter product name" class="form-control">
                </div>
            <?php endif; ?>
            
            <div class="form-group">
                <label class="form-label">Quantity</label>
                <input type="number" name="<?= $prefix ?>quantity[]" min="1" value="1" placeholder="Qty" class="form-control">
            </div>
            
            <div class="form-group">
                <label class="form-label">Dimensions</label>
                <input type="text" name="<?= $prefix ?>product_dimensions[]" placeholder="Dimensions"
                    class="form-control <?= $isExisting ? 'product-dimensions' : '' ?>">
            </div>
            
            <div class="form-group full-width">
                <label class="form-label">Description</label>
                <textarea name="<?= $prefix ?>product_description[]" rows="2"
                    placeholder="<?= $isExisting ? 'Additional notes...' : 'Product description...' ?>"
                    class="form-control"></textarea>
            </div>
            
            <div class="form-group full-width">
                <label class="form-label">Drawing File (Optional)</label>
                <div class="file-upload-wrapper">
                    <input type="file" name="drawing_file_<?= $type ?>[]" class="form-control" 
                           id="<?= $uniqueFileId ?>" onchange="previewSelectedFile(this)">
                    <label for="<?= $uniqueFileId ?>" class="file-upload-label">
                        <div class="file-upload-content">
                            <i class="bi bi-cloud-upload"></i>
                            <div class="file-upload-text">
                                <span class="file-upload-title">Click to upload drawing</span>
                                <!-- MODIFICATION: Updated subtitle to reflect any file type is allowed -->
                                <span class="file-upload-subtitle">Any file type - Max 10MB</span>
                            </div>
                        </div>
                    </label>
                </div>
                 <div class="file-preview-container" style="display:none;">
                    <div class="selected-file-info">
                        <span class="file-icon">📄</span>
                        <div class="file-details">
                            <span class="file-name"></span>
                            <span class="file-size"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}