<?php
// admin/dbconnection.php
$con = mysqli_connect("localhost", "root", "", "scrm_db");
if(mysqli_connect_errno()) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>