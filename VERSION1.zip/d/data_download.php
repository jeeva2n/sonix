<?php
session_start();
require_once 'functions.php';

// Ensure only admins can access
if (!isset($_SESSION['username']) || ($_SESSION['role'] ?? '') !== 'admin') {
    die('Access denied. Admin privileges required.');
}

try {
    if (isset($_GET['download']) || isset($_GET['view'])) {
        $filename = $_GET['download'] ?? $_GET['view'];
        $customName = $_GET['name'] ?? '';

        if ($filename === 'all') {
            if (isset($_GET['download'])) {
                downloadAllDataAsZip();
            } else {
                viewAllData();
            }
        } else {
            if (isset($_GET['download'])) {
                downloadCsvFile($filename, $customName);
            } else {
                viewCsvFile($filename, $customName);
            }
        }
        exit;
    }

    // If no valid parameters, redirect
    header('Location: data_management.php');
    exit;

} catch (Exception $e) {
    $_SESSION['message'] = ['type' => 'error', 'text' => 'Operation failed: ' . $e->getMessage()];
    header('Location: data_management.php');
    exit;
}