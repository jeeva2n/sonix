<?php
session_start();

// Check if user is logged in via dashboard system
if (!isset($_SESSION['login']) || !isset($_SESSION['id'])) {
    header('Location: login.php');
    exit();
}

// Map dashboard session to document manager session
$_SESSION['username'] = $_SESSION['login'];
$_SESSION['user_id'] = $_SESSION['id'];
$_SESSION['role'] = 'employee'; // Default role for dashboard users

// Redirect to document manager
header('Location: document-manager-employee.php');
exit();
?>