<?php
session_start();
require_once 'functions.php';

// Handle AJAX change logging
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if ($input && isset($input['action'])) {
        $changeEntry = [
            'order_id' => $input['order_id'] ?? '',
            'change_date' => date('Y-m-d H:i:s'),
            'changed_by' => $_SESSION['username'] ?? 'System',
            'stage' => $input['stage'] ?? '',
            'change_description' => $input['change_description'] ?? $input['action'],
            'action_type' => $input['action'],
            'item_index' => $input['item_index'] ?? '',
            'additional_data' => json_encode($input)
        ];

        appendCsvData('order_history.csv', $changeEntry);

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid data']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>