<?php
session_start();
require_once 'functions.php';

// Define standard statuses
$STANDARD_STATUSES = [
    'Pending',
    'Sourcing Material',
    'In Production',
    'Ready for QC',
    'QC Completed',
    'Packaging',
    'Ready for Dispatch',
    'Shipped'
];

// Get order ID from query parameter
$orderId = isset($_GET['order_id']) ? sanitize_input($_GET['order_id']) : '';

if (empty($orderId)) {
    die("Order ID is required");
}

// Get order data
$orders = getCsvData('orders.csv');
$customers = getCsvData('customers.csv');
$customerMap = array_column($customers, 'name', 'id');

$currentOrder = null;
foreach ($orders as $order) {
    if ($order['order_id'] == $orderId) {
        $currentOrder = $order;
        break;
    }
}

if (!$currentOrder) {
    die("Order not found");
}

// Parse items
$items = json_decode($currentOrder['items_json'], true) ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> - Order #<?= htmlspecialchars($currentOrder['order_id']) ?></title>
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Print-specific styles */
        @media print {
            @page {
                margin: 0.3in;
                size: A4;
            }
            
            body {
                font-family: "Segoe UI", Arial, sans-serif;
                font-size: 10px;
                line-height: 1.2;
                color: #000;
                background: white;
                margin: 0;
                padding: 0;
            }
            
            .print-header {
                text-align: center;
                margin-bottom: 15px;
                border-bottom: 1px solid #000;
                padding-bottom: 8px;
            }
            
            .print-header h1 {
                font-size: 14px;
                margin: 0 0 3px 0;
                font-weight: bold;
                letter-spacing: 0.5px;
            }
            
            .print-url {
                font-size: 8px;
                color: #666;
                margin: 0;
            }
            
            .order-info-section {
                margin-bottom: 15px;
                padding: 12px;
                border: 1px solid #000;
                border-radius: 3px;
            }
            
            .order-info-section h2 {
                font-size: 11px;
                margin: 0 0 8px 0;
                font-weight: bold;
                background: #f0f0f0;
                padding: 4px 8px;
                border-radius: 2px;
            }
            
            .order-details-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 6px;
            }
            
            .detail-item {
                display: flex;
                margin-bottom: 3px;
            }
            
            .detail-label {
                font-weight: bold;
                min-width: 70px;
                font-size: 9px;
            }
            
            .detail-value {
                flex: 1;
                font-size: 9px;
            }
            
            .item-card {
                margin-bottom: 15px;
                border: 1px solid #ccc;
                border-radius: 3px;
                padding: 10px;
                page-break-inside: avoid;
            }
            
            .item-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 8px;
                padding-bottom: 6px;
                border-bottom: 1px solid #eee;
            }
            
            .item-title {
                font-size: 11px;
                font-weight: bold;
                margin: 0;
            }
            
            .item-quantity {
                font-size: 10px;
                color: #ffe6e6ff;
            }
            
            .item-dimensions {
                margin-bottom: 8px;
                padding: 6px;
                background: #f8f9fa;
                border-radius: 2px;
                font-size: 9px;
            }
            
            .stage-section {
                margin-bottom: 12px;
                page-break-inside: avoid;
            }
            
            .stage-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 6px;
                padding: 5px 8px;
                background: #f8f9fa;
                border-radius: 2px;
                font-weight: bold;
                font-size: 10px;
                border-left: 3px solid #007bff;
            }
            
            .stage-content {
                padding: 0 8px;
            }
            
            .data-table {
                width: 100%;
                border-collapse: collapse;
                font-size: 9px;
                margin-bottom: 8px;
            }
            
            .data-table th,
            .data-table td {
                border: 1px solid #ccc;
                padding: 3px 5px;
                text-align: left;
            }
            
            .data-table th {
                background: #e9ecef;
                font-weight: bold;
            }
            
            .process-entry,
            .inspection-entry,
            .packaging-lot {
                margin-bottom: 10px;
                padding: 6px;
                border: 1px solid #e0e0e0;
                border-radius: 2px;
                background: #fafafa;
            }
            
            .process-header,
            .inspection-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 4px;
            }
            
            .process-title,
            .inspection-title {
                font-size: 10px;
                font-weight: bold;
                margin: 0;
            }
            
            .process-details,
            .inspection-details {
                font-size: 9px;
                margin-bottom: 4px;
            }
            
            .process-details div,
            .inspection-details div {
                margin-bottom: 2px;
            }
            
            .status-badge {
                display: inline-block;
                padding: 1px 6px;
                border-radius: 10px;
                font-size: 8px;
                font-weight: bold;
                margin-left: 6px;
            }
            
            .status-completed { background: #d4edda; color: #155724; }
            .status-pending { background: #fff3cd; color: #856404; }
            .status-in-progress { background: #cce7ff; color: #004085; }
            
            .document-item {
                display: inline-flex;
                align-items: center;
                background: white;
                padding: 2px 6px;
                border: 1px solid #ddd;
                border-radius: 2px;
                margin: 1px;
                font-size: 8px;
            }
            
            .packaging-info {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
                gap: 6px;
                font-size: 9px;
                margin-bottom: 6px;
            }
            
            .fumigation-details {
                background: #d4edda;
                padding: 5px;
                border-radius: 2px;
                border: 1px solid #c3e6cb;
                margin-bottom: 6px;
                font-size: 9px;
            }
            
            .dispatch-details {
                background: #d4edda;
                padding: 6px;
                border-radius: 2px;
                border: 1px solid #c3e6cb;
                font-size: 9px;
            }
            
            .inspection-summary {
                background: #e8f4fd;
                padding: 8px;
                border-radius: 2px;
                margin-top: 8px;
                border: 1px solid #bee5eb;
                font-size: 9px;
            }
            
            .summary-stats {
                display: flex;
                gap: 12px;
                margin-bottom: 4px;
            }
            
            .page-break {
                page-break-before: always;
            }
            
            .print-footer {
                text-align: center;
                margin-top: 15px;
                padding-top: 8px;
                border-top: 1px solid #ccc;
                font-size: 8px;
                color: #666;
            }
            
            /* Hide non-print elements */
            .no-print {
                display: none !important;
            }
        }
        
        /* Screen styles for preview */
        @media screen {
            body {
                font-family: "Segoe UI", Arial, sans-serif;
                max-width: 210mm;
                margin: 20px auto;
                padding: 20px;
                background: #f5f5f5;
            }
            
            .print-container {
                background: white;
                padding: 25px;
                box-shadow: 0 0 20px rgba(0,0,0,0.1);
                min-height: 297mm;
            }
            
            .print-actions {
                text-align: center;
                margin-bottom: 20px;
                padding: 15px;
                background: white;
                border-radius: 5px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            
            .btn {
                padding: 8px 16px;
                margin: 0 8px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                font-size: 12px;
                text-decoration: none;
                display: inline-block;
            }
            
            .btn-primary {
                background: #007bff;
                color: white;
            }
            
            .btn-secondary {
                background: #6c757d;
                color: white;
            }
        }
    </style>
</head>
<body>
    <!-- Print Actions (Visible only on screen) -->
    <div class="print-actions no-print">
        <button onclick="window.print()" class="btn btn-primary">🖨️ Print Document</button>
        <button onclick="window.close()" class="btn btn-secondary">❌ Close</button>
        <a href="pipeline.php" class="btn btn-secondary">📊 Back to Pipeline</a>
    </div>

    <!-- Print Content -->
    <div class="print-container">
        <!-- Page 1: Order Information -->
        <div class="print-header">
            <h1></h1>
            <p class="print-url">localhost/alpha/alpha/pipeline.php</p>
        </div>

        <div class="order-info-section">
            <h2># Order Information</h2>
            <div class="order-details-grid">
                <div class="detail-item">
                    <span class="detail-label"><strong>Order #:</strong></span>
                    <span class="detail-value"><?= htmlspecialchars($currentOrder['order_id']) ?></span>
                </div>
                <div class="detail-item">
                    <span class="detail-label"><strong>Client:</strong></span>
                    <span class="detail-value"><?= htmlspecialchars($customerMap[$currentOrder['customer_id']] ?? 'N/A') ?></span>
                </div>
                <div class="detail-item">
                    <span class="detail-label"><strong>PO Date:</strong></span>
                    <span class="detail-value"><?= htmlspecialchars($currentOrder['po_date']) ?></span>
                </div>
                <div class="detail-item">
                    <span class="detail-label"><strong>Delivery:</strong></span>
                    <span class="detail-value"><?= htmlspecialchars($currentOrder['delivery_date'] ?? 'N/A') ?></span>
                </div>
            </div>
        </div>

        <?php foreach ($items as $itemIndex => $item): ?>
            <div class="item-card">
                <!-- Item Header -->
                <div class="item-header">
                    <h3 class="item-title">▶ <?= htmlspecialchars($item['Name'] ?? 'Unnamed Item') ?></h3>
                    <div class="item-quantity">Qty: <?= htmlspecialchars($item['quantity'] ?? '1') ?></div>
                </div>

                <?php if (!empty($item['Dimensions']) || !empty($item['Description'])): ?>
                    <div class="item-dimensions">
                        <?php if (!empty($item['Dimensions'])): ?>
                            <div><strong>Dimensions:</strong> <?= htmlspecialchars(str_replace('"', '&quot;', $item['Dimensions'])) ?></div>
                        <?php endif; ?>
                        <?php if (!empty($item['Description'])): ?>
                            <div><strong>Description:</strong> <?= htmlspecialchars($item['Description']) ?></div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <!-- Stage 2: Raw Materials -->
                <?php if (!empty($item['raw_materials'])): ?>
                    <div class="stage-section">
                        <div class="stage-header">
                            <span>🔧 Stage 2: Raw Materials Sourcing</span>
                            <small>Person in charge: Procurement Head</small>
                        </div>
                        <div class="stage-content">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>TYPE</th>
                                        <th>GRADE</th>
                                        <th>DIMENSIONS</th>
                                        <th>VENDOR</th>
                                        <th>DATE</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($item['raw_materials'] as $material): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($material['type'] ?? '') ?></td>
                                            <td><?= htmlspecialchars($material['grade'] ?? '') ?></td>
                                            <td><?= htmlspecialchars($material['dimensions'] ?? '') ?></td>
                                            <td><?= htmlspecialchars($material['vendor'] ?? '') ?></td>
                                            <td><?= htmlspecialchars($material['purchase_date'] ?? '') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Stage 3: Machining Processes -->
                <?php if (!empty($item['machining_processes'])): ?>
                    <div class="stage-section">
                        <div class="stage-header">
                            <span>⚙️ Stage 3: Machining Processes</span>
                            <small>Person in charge: Production Manager</small>
                        </div>
                        <div class="stage-content">
                            <?php foreach ($item['machining_processes'] as $process): ?>
                                <div class="process-entry">
                                    <div class="process-header">
                                        <h4 class="process-title">
                                            Seq #<?= htmlspecialchars($process['sequence'] ?? '') ?>: <?= htmlspecialchars($process['name'] ?? '') ?>
                                            <span class="status-badge status-<?= strtolower(str_replace(' ', '-', $process['status'] ?? 'pending')) ?>">
                                                <?= htmlspecialchars($process['status'] ?? 'Pending') ?>
                                            </span>
                                        </h4>
                                    </div>
                                    <div class="process-details">
                                        <div><strong>Vendor:</strong> <?= htmlspecialchars($process['vendor'] ?? '') ?></div>
                                        <div><strong>Start Date:</strong> <?= htmlspecialchars($process['start_date'] ?? '') ?></div>
                                        <div><strong>Expected Completion:</strong> <?= htmlspecialchars($process['expected_completion'] ?? '') ?></div>
                                        <?php if (!empty($process['actual_completion'])): ?>
                                            <div><strong>Actual Completion:</strong> <?= htmlspecialchars($process['actual_completion']) ?></div>
                                        <?php endif; ?>
                                        <?php if (!empty($process['remarks'])): ?>
                                            <div><strong>Remarks:</strong> <?= htmlspecialchars($process['remarks']) ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($process['documents'])): ?>
                                        <div style="margin-top: 4px;">
                                            <strong>Documents:</strong>
                                            <?php foreach ($process['documents'] as $docIndex => $doc): ?>
                                                <div class="document-item">
                                                    📄 <?= htmlspecialchars($process['original_filenames'][$docIndex] ?? $doc) ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Stage 4: Quality Inspection -->
                <?php if (!empty($item['inspection_data'])): ?>
                    <div class="stage-section">
                        <div class="stage-header">
                            <span>🔍 Stage 4: Quality Inspection</span>
                            <small>Person in charge: QC Manager</small>
                        </div>
                        <div class="stage-content">
                            <?php 
                            $inspections = $item['inspection_data'];
                            usort($inspections, function ($a, $b) {
                                return strtotime($b['inspection_date'] ?? '') - strtotime($a['inspection_date'] ?? '');
                            });
                            ?>

                            <?php foreach ($inspections as $inspIndex => $inspection): ?>
                                <div class="inspection-entry">
                                    <div class="inspection-header">
                                        <h4 class="inspection-title">
                                            Inspection #<?= (count($inspections) - $inspIndex) ?>: <?= htmlspecialchars($inspection['type'] ?? '') ?>
                                            <span class="status-badge" style="background: 
                                                <?= ($inspection['status'] ?? '') == 'QC Passed' ? '#d4edda' : 
                                                   (($inspection['status'] ?? '') == 'Rework Required' ? '#f8d7da' : '#fff3cd') ?>; 
                                                color: <?= ($inspection['status'] ?? '') == 'QC Passed' ? '#155724' : 
                                                        (($inspection['status'] ?? '') == 'Rework Required' ? '#721c24' : '#856404') ?>;">
                                                <?= htmlspecialchars($inspection['status'] ?? '') ?>
                                            </span>
                                        </h4>
                                        <small style="color: #666;">
                                            <?= date('M j, Y', strtotime($inspection['inspection_date'] ?? '')) ?>
                                        </small>
                                    </div>
                                    <div class="inspection-details">
                                        <div><strong>Technician:</strong> <?= htmlspecialchars($inspection['technician_name'] ?? '') ?></div>
                                        <div><strong>Inspection Date:</strong> <?= htmlspecialchars($inspection['inspection_date'] ?? '') ?></div>
                                        <div><strong>Inspection ID:</strong> <?= htmlspecialchars($inspection['inspection_id'] ?? 'N/A') ?></div>
                                        <?php if (!empty($inspection['remarks'])): ?>
                                            <div><strong>Remarks:</strong> <?= htmlspecialchars($inspection['remarks']) ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <?php if (!empty($inspection['documents'])): ?>
                                        <div style="margin-top: 4px;">
                                            <strong>QC Reports/Documents:</strong>
                                            <?php foreach ($inspection['documents'] as $docIndex => $doc): ?>
                                                <div class="document-item">
                                                    📄 <?= htmlspecialchars($inspection['original_filenames'][$docIndex] ?? $doc) ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>

                            <!-- Inspection Summary -->
                            <div class="inspection-summary">
                                <h5 style="margin: 0 0 6px 0; font-size: 10px; color: #2c5282;">📊 Inspection Summary</h5>
                                <?php
                                $passCount = 0;
                                $reworkCount = 0;
                                $minorCount = 0;
                                foreach ($item['inspection_data'] as $insp) {
                                    if (($insp['status'] ?? '') === 'QC Passed') $passCount++;
                                    elseif (($insp['status'] ?? '') === 'Rework Required') $reworkCount++;
                                    else $minorCount++;
                                }
                                ?>
                                <div class="summary-stats">
                                    <div><span style="color: #28a745;">✓ Passed:</span> <?= $passCount ?></div>
                                    <div><span style="color: #dc3545;">⟲ Rework:</span> <?= $reworkCount ?></div>
                                    <div><span style="color: #ffc107;">⚠ Minor Issues:</span> <?= $minorCount ?></div>
                                </div>
                                <div style="margin-top: 3px;">
                                    <strong>Total Inspections:</strong> <?= count($item['inspection_data']) ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Stage 5: Packaging -->
                <?php if (!empty($item['packaging_lots'])): ?>
                    <div class="stage-section">
                        <div class="stage-header">
                            <span>📦 Stage 5: Packaging</span>
                            <small>Person in charge: Packaging Team</small>
                        </div>
                        <div class="stage-content">
                            <?php foreach ($item['packaging_lots'] as $lotIndex => $lot): ?>
                                <div class="packaging-lot">
                                    <h4 style="margin: 0 0 6px 0; font-size: 10px; color: #2c5282;">
                                        Lot #<?= ($lotIndex + 1) ?> - <?= htmlspecialchars($lot['products_in_lot'] ?? '') ?> products
                                    </h4>

                                    <div class="packaging-info">
                                        <div><strong>Packaging Type:</strong> <?= htmlspecialchars($lot['packaging_type'] ?? '') ?></div>
                                        <div><strong>Date:</strong> <?= htmlspecialchars($lot['packaging_date'] ?? '') ?></div>
                                        <div><strong>Packages:</strong> <?= htmlspecialchars($lot['num_packages'] ?? '') ?></div>
                                        <div><strong>Net Weight:</strong> <?= htmlspecialchars($lot['net_weight'] ?? '') ?> kg</div>
                                        <div><strong>Gross Weight:</strong> <?= htmlspecialchars($lot['gross_weight'] ?? '') ?> kg</div>
                                        <div><strong>Docs Included:</strong> <?= htmlspecialchars($lot['docs_included'] ?? 'No') ?></div>
                                    </div>

                                    <!-- Fumigation Information -->
                                    <?php if (!empty($lot['fumigation_completed']) && $lot['fumigation_completed'] === 'Yes'): ?>
                                        <div class="fumigation-details">
                                            <strong>✅ Fumigation Details:</strong>
                                            <div style="margin-top: 2px;">
                                                Certificate #<?= htmlspecialchars($lot['fumigation_certificate_number'] ?? 'N/A') ?> | 
                                                Date: <?= htmlspecialchars($lot['fumigation_date'] ?? 'N/A') ?> | 
                                                Agency: <?= htmlspecialchars($lot['fumigation_agency'] ?? 'N/A') ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Product Photos -->
                                    <?php if (!empty($lot['photos'])): ?>
                                        <div style="margin-bottom: 6px;">
                                            <strong>Product Photos:</strong>
                                            <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 2px;">
                                                <?php foreach ($lot['photos'] as $photoIndex => $photo): ?>
                                                    <div class="document-item">
                                                        🖼️ <?= htmlspecialchars($lot['original_photo_names'][$photoIndex] ?? $photo) ?>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Stage 6: Shipping Documentation -->
                                    <?php if (!empty($lot['shipping_documents'])): ?>
                                        <div class="stage-section">
                                            <div class="stage-header">
                                                <span>📋 Stage 6: Shipping Documentation - Lot #<?= ($lotIndex + 1) ?></span>
                                                <small>Person in charge: Documentation Team</small>
                                            </div>
                                            <div class="stage-content">
                                                <strong>Shipping Documents:</strong>
                                                <div style="display: flex; flex-wrap: wrap; gap: 4px; margin-top: 2px;">
                                                    <?php foreach ($lot['shipping_documents'] as $docIndex => $doc): ?>
                                                        <div class="document-item">
                                                            📄 <?= htmlspecialchars($lot['shipping_original_filenames'][$docIndex] ?? $doc) ?>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Stage 7: Dispatch -->
                                    <?php if (!empty($lot['dispatch_status'])): ?>
                                        <div class="stage-section">
                                            <div class="stage-header">
                                                <span>🚚 Stage 7: Dispatch - Lot #<?= ($lotIndex + 1) ?></span>
                                                <small>Person in charge: Logistics Team</small>
                                            </div>
                                            <div class="stage-content">
                                                <div class="dispatch-details">
                                                    <strong>✅ Dispatched Successfully</strong>
                                                    <div style="margin-top: 3px;">
                                                        <div><strong>Dispatch Date:</strong> <?= htmlspecialchars($lot['dispatch_date'] ?? '') ?></div>
                                                        <div><strong>Transport:</strong> <?= htmlspecialchars($lot['transport_mode'] ?? '') ?></div>
                                                        <div><strong>Tracking #:</strong> <?= htmlspecialchars($lot['tracking_number'] ?? '') ?></div>
                                                        <?php if (!empty($lot['dispatch_remarks'])): ?>
                                                            <div><strong>Remarks:</strong> <?= htmlspecialchars($lot['dispatch_remarks']) ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <div class="print-footer">
            Page 1 of 1 • <?= date('m/d/y, g:i A') ?> • 
        </div>
    </div>

    <script>
        // Auto-print when page loads
        window.onload = function() {
            // Auto-print when page loads - remove if you don't want auto-print
            setTimeout(function() {
                window.print();
            }, 500);
        };
    </script>
</body>
</html>